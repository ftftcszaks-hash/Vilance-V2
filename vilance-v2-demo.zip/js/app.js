// demo client-side flow only
const screens = {
  welcome: document.getElementById('screen-welcome'),
  login: document.getElementById('screen-login'),
  register: document.getElementById('screen-register'),
  dashboard: document.getElementById('screen-dashboard'),
  bug: document.getElementById('screen-bug'),
};

function show(id){
  Object.values(screens).forEach(s=>s.classList.remove('active'));
  screens[id].classList.add('active');
}

/* default */
show('welcome');

/* navigation buttons */
document.querySelectorAll('[data-action]').forEach(btn=>{
  btn.addEventListener('click', (e)=>{
    const a = e.currentTarget.getAttribute('data-action');
    switch(a){
      case 'goto-login': show('login'); break;
      case 'goto-register': show('register'); break;
      case 'back-welcome': show('welcome'); break;
      case 'open-bug': show('bug'); break;
      case 'open-chat': alert('Fitur chat demo — belum diimplementasikan.'); break;
      case 'back-dashboard': show('dashboard'); break;
    }
  });
});

/* demo login check */
const DEMO_USERNAME = 'Vilance';
const DEMO_PASSWORD = 'ZakzzDev';

document.getElementById('btn-login').addEventListener('click', ()=>{
  const u = document.getElementById('input-username').value.trim();
  const p = document.getElementById('input-password').value.trim();
  if(u === DEMO_USERNAME && p === DEMO_PASSWORD){
    alert('Login berhasil (demo). Masuk ke Dashboard.');
    show('dashboard');
  } else {
    alert('Login gagal. Gunakan demo credentials: username: Vilance password: ZakzzDev');
  }
});

/* demo register */
document.getElementById('btn-register').addEventListener('click', ()=>{
  alert('Pendaftaran demo selesai. Silakan login dengan username Vilance / password ZakzzDev');
  show('login');
});

/* send bug (DEMO only) */
document.getElementById('btn-send-bug').addEventListener('click', ()=>{
  const target = document.getElementById('target-number').value.trim();
  const bug = document.getElementById('select-bug').value;
  if(!target || !bug){ alert('Isi nomor target dan pilih bug (demo).'); return; }
  // IMPORTANT: demo only
  alert('DEMO: tombol tidak menjalankan aksi apapun yang berbahaya.\nTarget: ' + target + '\nPilihan: ' + bug);
});
/* logout */
document.getElementById('btn-logout').addEventListener('click', ()=> show('welcome'));
