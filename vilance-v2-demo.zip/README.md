Vilance V2 — Demo Project
------------------------

Ini paket demo untuk UI aplikasi "Vilance V2". Fitur:
- Welcome screen (login/register)
- Login screen (demo credentials)
- Dashboard with 3 buttons (Menu Bug, WhatsApp, Chat)
- Bug form (DEMO only) with options DELAY ANDROID and DELAY IOS
- Buttons membuka WhatsApp ke nomor: +62 858-1407-7011
- Saluran dev link ke: https://whatsapp.com/channel/0029VbAcXaaC6ZvZreAKvm0g

Cara pakai:
1. Ekstrak `vilance-v2-demo.zib` (zip). Ganti ekstensi ke .zip jika diperlukan.
2. Buka index.html di browser.
3. Login demo: username=Vilance password=ZakzzDev

Catatan:
- Gambar banner & logo memakai link eksternal ke pixhost (butuh internet untuk menampilkan).
- Tombol "Send Bug" hanya demo; tidak menjalankan aksi berbahaya.
- Jangan menyalahgunakan aplikasi ini untuk merusak pihak lain.
